﻿DeskClear 1.0.5 便携版
========================

1. 请先「全部解压」到一个文件夹，再使用。不要只从压缩包里拖出 exe（缺少 dll 无法运行）。
2. 解压后 DeskClear.exe 会显示应用图标，可把它或整个文件夹放到桌面。
3. 双击 DeskClear.exe 运行。dll 和 platforms 必须与 exe 放在同一文件夹。

要求：64 位 Windows 10/11。
